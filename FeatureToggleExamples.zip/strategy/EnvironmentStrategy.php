<?php
interface EnvironmentStrategy {
	function useConf();
	function listFeatures();
}
?>
